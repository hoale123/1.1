package com.company.interfaceapproach;

public interface Shape {

    double perimeter();
    double area();
}
