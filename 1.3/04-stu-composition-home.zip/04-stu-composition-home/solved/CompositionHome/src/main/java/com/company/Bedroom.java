package com.company;

public class Bedroom extends Room {
    private String bedSize;

    public String getBedSize() {
        return bedSize;
    }

    public void setBedSize(String bedSize) {
        this.bedSize = bedSize;
    }
}
