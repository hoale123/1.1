package com.company;

public class UnsimpleAdder {

    public static int addInts(int a, int b) {
        return a + b;
    }

    public static long addLongs(long a, long b) {
        return a + b;
    }

    public static float addFloats(float a, float b) {
        return a + b;
    }

    public static double addDoubles(double a, double b) {
        return a + b;
    }

}
