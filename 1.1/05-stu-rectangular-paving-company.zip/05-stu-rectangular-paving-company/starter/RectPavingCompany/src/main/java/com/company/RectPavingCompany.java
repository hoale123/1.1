package com.company;

public class RectPavingCompany {

    public static void main(String[] args) {

    }
}
